from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import mysql.connector  # Add this line for MySQL connection

app = Flask(__name__)
app.secret_key = b'\xced=<}\xee\x7f}\x0b\x94q\xa2\x1f\xcd\xad\xab\x9d5\xa51\x96oy\x84'

# Add your MySQL database connection here
db = mysql.connector.connect(
    host="localhost",
    user="root",  # default XAMPP MySQL username
    password="",  # default XAMPP MySQL password (empty)
    database="project_database"  # your database name
)

cursor = db.cursor()

# Example function to interact with the database
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        name = request.form['username']
        email = request.form['email']
        password = request.form['password']
        
        # Check if email exists
        cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
        existing_user = cursor.fetchone()
        
        if existing_user:
            return "Email already registered, please log in."
        
        # Add user to the MySQL database
        cursor.execute("INSERT INTO users (name, email, password) VALUES (%s, %s, %s)", (name, email, password))
        db.commit()  # Don't forget to commit the transaction
        
        session['user'] = email
        return redirect(url_for('login'))

    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        # Fetch the user from the MySQL database
        cursor.execute("SELECT name, email FROM users WHERE email = %s AND password = %s", (email, password))
        user = cursor.fetchone()

        if user:
            session['user'] = user[0]
            return redirect(url_for('main'))
        else:
            return "Invalid credentials, please try again."

    return render_template('login.html')

@app.route('/cart-details')
def cart_details():
    # Render the cart details page
    return render_template('cart_details.html')

# Route to handle the review submission
@app.route('/submit-reviews', methods=['POST'])
def submit_reviews():
    data = request.json.get('reviews', [])
    username = session.get('user')  # Fetch username from session

    # Insert each review into cart_items table
    try:
        for review in data:
            cursor.execute(
                "INSERT INTO cart_items (username, product_name, review) VALUES (%s, %s, %s)",
                (username, review['name'], review['review'])
            )
        db.commit()
        response = {'success': True}
    except Exception as e:
        db.rollback()
        response = {'success': False, 'error': str(e)}
    return jsonify(response)

# Add this route to fetch reviews from the database and group them by product name
@app.route('/product-reviews')
def product_reviews():
    with db.cursor(dictionary=True) as cursor:  # Ensures fetching as dictionaries
        cursor.execute("SELECT product_name, username, review FROM cart_items")
        reviews = cursor.fetchall()


    # Group reviews by product name
    product_reviews = {}
    for review in reviews:
        product_reviews.setdefault(review['product_name'], []).append({
            'username': review['username'],
            'review': review['review']
        })

    return render_template('clothes.html', product_reviews=product_reviews)  # Ensure this matches the template where reviews should appear

# Index route (main page, shown after login)
@app.route('/main')
def main():
    if 'user' in session:  # Check if user is logged in
        user = session['user']  # Get the logged-in username from session
        return render_template('main.html', user=user)  # Pass the username to the template
    else:
        return redirect(url_for('login'))  # Redirect to login if not logged in

# Logout route
@app.route('/logout')
def logout():
    session.pop('user', None)  # Remove user from session
    return redirect(url_for('login'))  # Redirect to login after logout
# Products dictionary
products = {
    1: {"name": "Stylish Shirt", "image": "/static/clothes_img/s1.jpeg", "price": "29.99", "description": "A stylish and comfortable shirt perfect for any occasion."},
    2: {"name": "Casual Button-Up Shirt", "image": "/static/clothes_img/s2.jpeg", "price": "34.99", "description": "A relaxed-fit button-up shirt ideal for weekend outings."},
    3: {"name": "Graphic Tee", "image": "/static/clothes_img/s3.jpg", "price": "24.99", "description": "A fun graphic tee to express your unique style."},
    4: {"name": "Long Sleeve Shirt", "image": "/static/clothes_img/s4.jpeg", "price": "39.99", "description": "A versatile long sleeve shirt suitable for layering."},
    5: {"name": "Slim Fit Shirt", "image": "/static/clothes_img/s5.jpeg", "price": "49.99", "description": "A tailored slim fit shirt for a modern look."},
    6: {"name": "Casual Pants", "image": "/static/clothes_img/p2.jpeg", "price": "39.99", "description": "Versatile pants that can be dressed up or down."},
    7: {"name": "Slim Fit Pants", "image": "/static/clothes_img/p3.jpeg", "price": "44.99", "description": "Sleek slim-fit pants that offer both style and comfort."},
    8: {"name": "Jogger Pants", "image": "/static/clothes_img/p4.jpeg", "price": "29.99", "description": "Comfortable joggers, perfect for casual wear and workouts."},
    9: {"name": "Cargo Pants", "image": "/static/clothes_img/p1.jpeg", "price": "49.99", "description": "Durable cargo pants with plenty of pockets for utility."},
    10: {"name": "Chino Pants", "image": "/static/clothes_img/p5.jpeg", "price": "34.99", "description": "Lightweight and breathable chinos, great for smart-casual outfits."},
    31: {"name": "iPhone 15 Pro", "image": "/static/mobile_img/m1.webp", "price": "999.99", "description": "The latest iPhone with an A17 chip and stunning camera."},
    32: {"name": "Samsung Galaxy S24 Ultra", "image": "/static/mobile_img/m2.webp", "price": "1199.99", "description": "A powerful smartphone with a stunning display and camera."},
    33: {"name": "Google Pixel 8 Pro", "image": "/static/mobile_img/m11.jpeg", "price": "999.00", "description": "The latest Pixel phone with exceptional AI features."},
    34: {"name": "OnePlus 11", "image": "/static/mobile_img/m5.jpeg", "price": "899.99", "description": "A flagship phone with fast performance and great design."},
    35: {"name": "Xiaomi 12 Pro", "image": "/static/mobile_img/m4.jpeg", "price": "1099.99", "description": "A high-end smartphone with impressive specs and features."}
}


# Reviews dictionary to store product reviews
reviews = {key: [] for key in products.keys()}

@app.route('/')
def home():
    return render_template('login.html')

@app.route('/clothes')
def clothes():
    cursor = db.cursor(dictionary=True)
    
    # Fetch reviews grouped by product_name
    cursor.execute("SELECT username, product_name, review FROM cart_items")
    reviews = cursor.fetchall()
    
    # Organize reviews by product_name
    product_reviews = {}
    for review in reviews:
        product = review["product_name"]
        if product not in product_reviews:
            product_reviews[product] = []
        product_reviews[product].append(review)
    
    cursor.close()
    return render_template("clothes.html", product_reviews=product_reviews)


@app.route('/health')
def health():
    return render_template('health.html')

@app.route('/furniture')
def furniture():
    return render_template('furniture.html')

@app.route('/mobile')
def mobile():
    return render_template('mobile.html')

@app.route('/beauty')
def beauty():
    return render_template('beauty.html')

@app.route('/petcare')
def petcare():
    return render_template('petcare.html')

@app.route('/toys')
def toys():
    return render_template('toys.html')

# Clothes section routes
@app.route('/clothes/cloth1')
def cloth1():
    return render_template('clothes/cloth1.html', products={key: products[key] for key in range(1, 6)})

@app.route('/clothes/cloth2')
def cloth2():
    return render_template('clothes/cloth2.html', products={key: products[key] for key in range(6, 11)})

@app.route('/clothes/cloth3')
def cloth3():
    return render_template('clothes/cloth3.html', products={key: products[key] for key in range(11, 16)})

@app.route('/clothes/cloth4')
def cloth4():
    return render_template('clothes/cloth4.html', products={key: products[key] for key in range(16, 21)})

@app.route('/clothes/cloth5')
def cloth5():
    return render_template('clothes/cloth5.html', products={key: products[key] for key in range(21, 26)})

@app.route('/clothes/cloth6')
def cloth6():
    return render_template('clothes/cloth6.html', products={key: products[key] for key in range(26, 31)})

@app.route('/clothes/<int:product_id>', methods=['GET', 'POST'])
def product_detail(product_id):
    product = products.get(product_id)
    
    if request.method == 'POST':
        rating = request.form.get('rating')
        review_text = request.form.get('review')
        if rating and review_text:
            reviews[product_id].append({'rating': rating, 'text': review_text})

    return render_template('product_detail.html', product=product, reviews=reviews[product_id])

# Mobile section routes
@app.route('/mobile/mobile1')
def mobile1():
    return render_template('mobile/mobile1.html', products={key: products[key] for key in range(31, 36)})

@app.route('/mobile/mobile2')
def mobile2():
    return render_template('mobile/mobile2.html', products={key: products[key] for key in range(36, 41)})

@app.route('/mobile/mobile3')
def mobile3():
    return render_template('mobile/mobile3.html', products={key: products[key] for key in range(41, 46)})

@app.route('/mobile/mobile4')
def mobile4():
    return render_template('mobile/mobile4.html', products={key: products[key] for key in range(46, 51)})

@app.route('/mobile/mobile5')
def mobile5():
    return render_template('mobile/mobile5.html', products={key: products[key] for key in range(51, 56)})

@app.route('/mobile/mobile6')
def mobile6():
    return render_template('mobile/mobile6.html', products={key: products[key] for key in range(56, 61)})

@app.route('/mobile/<int:product_id>', methods=['GET', 'POST'])
def product_detail_mobile(product_id):
    product = products.get(product_id)
    
    if request.method == 'POST':
        rating = request.form.get('rating')
        review_text = request.form.get('review')
        if rating and review_text:
            reviews[product_id].append({'rating': rating, 'text': review_text})

    return render_template('product_detail.html', product=product, reviews=reviews[product_id])


if __name__ == '__main__':
    app.run(debug=True)
